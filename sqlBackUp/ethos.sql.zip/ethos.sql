-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 08, 2022 at 12:16 AM
-- Server version: 8.0.27
-- PHP Version: 7.3.33-1+ubuntu20.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ethos`
--

-- --------------------------------------------------------

--
-- Table structure for table `academics`
--

CREATE TABLE `academics` (
  `id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tab_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `body` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `academics`
--

INSERT INTO `academics` (`id`, `title`, `tab_title`, `body`, `image`, `approved`, `created`, `updated`) VALUES
(1, 'Test 1', 'Upper', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '4image005_cf143.jpg', 1, '2015-11-06 19:37:05', '2015-11-06 19:37:05'),
(2, 'Test 2', 'Middle', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', 'image025_d9bd5.jpg', 1, '2015-11-06 19:40:20', '2015-11-06 19:40:20'),
(3, 'Test 3', 'Lower', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n', '2image003_df790.jpg', 1, '2015-11-06 19:40:56', '2015-11-06 19:40:56');

-- --------------------------------------------------------

--
-- Table structure for table `agreements`
--

CREATE TABLE `agreements` (
  `id` int NOT NULL,
  `item_id` int NOT NULL DEFAULT '0',
  `item_type` int NOT NULL DEFAULT '0',
  `member_id` int NOT NULL DEFAULT '0',
  `agree_flag` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE `albums` (
  `id` int NOT NULL,
  `title` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keywords` text NOT NULL,
  `header` text NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `albums`
--

INSERT INTO `albums` (`id`, `title`, `meta_description`, `meta_keywords`, `header`, `created`, `updated`, `approved`) VALUES
(19, '<p>\r\n	Be Healthy Week</p>\r\n', 'Be Healthy Week 2019 - 2020', '', '', '2019-12-15 10:27:24', '2019-12-19 13:25:16', 1),
(20, '<p>\r\n	Etholympics</p>\r\n', '', '', '', '2019-12-19 13:21:46', '2019-12-19 13:24:14', 1),
(21, '<p>\r\n	Ethos Works</p>\r\n', 'Ethos Works', '', '', '2019-12-19 14:13:05', '2019-12-19 14:14:18', 1),
(22, '<p>\r\n	Future Campus</p>\r\n', '', '', '', '2021-01-30 18:51:51', '2021-02-02 10:16:06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` datetime NOT NULL,
  `header` text NOT NULL,
  `header_ar` text,
  `body` longtext NOT NULL,
  `body_ar` longtext,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `hits` int NOT NULL DEFAULT '0',
  `shared` int NOT NULL DEFAULT '0',
  `like` int NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `creator` varchar(255) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE `attachments` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `downloads` int NOT NULL DEFAULT '0',
  `node_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `attend_events`
--

CREATE TABLE `attend_events` (
  `id` int NOT NULL,
  `event_id` int NOT NULL DEFAULT '0',
  `member_id` int NOT NULL DEFAULT '0',
  `attend_flag` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `audios`
--

CREATE TABLE `audios` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `hits` int NOT NULL,
  `album_id` int NOT NULL,
  `header` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `blocked_members`
--

CREATE TABLE `blocked_members` (
  `id` int NOT NULL,
  `member_id` int NOT NULL DEFAULT '0',
  `blocked_member_id` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE `careers` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `to_email` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`id`, `title`, `description`, `to_email`, `created`, `updated`, `approved`, `weight`) VALUES
(2, 'Art Teacher', '<p>\r\n	<strong><span style=\"font-size:16px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Description:</span></span></strong></p>\r\n<p>\r\n	<span style=\"font-size:18px;\"><span style=\"font-size:16px;\">For educators who are excited to join a forward-thinking, well-resourced and highly productive and creative Art Department, we are seeking to hire a full-time multi-skilled Art Teacher for our Foundation and Key Stage 1 &amp; 2 pupils with an excellent track record and a strong understanding of curriculum opportunities and development.</span></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong style=\"font-family: arial, helvetica, sans-serif;\"><span style=\"font-size:18px;\"><span style=\"font-size:16px;\">Qualifications:</span></span></strong></p>\r\n<ul>\r\n	<li>\r\n		<span style=\"font-size: 16px;\">Preferrably faculty of Art graduate.</span></li>\r\n	<li>\r\n		<span style=\"font-size: 16px;\">3-5 years of experience.</span></li>\r\n	<li>\r\n		<span style=\"font-size:18px;\"><span style=\"font-size:16px;\">Good command in English language.</span></span></li>\r\n	<li>\r\n		<span style=\"font-size:18px;\"><span style=\"font-size:16px;\">Preferrably experienced in photoshop and graphics.</span></span></li>\r\n	<li>\r\n		Studied IGCSE Art is a plus</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2015-11-20 00:26:08', '2020-09-16 11:36:50', 0, 0),
(3, 'Key Stage One Class Teacher', '<p>\r\n	<strong>Description:</strong></p>\r\n<p>\r\n	We are looking for a committed teacher&nbsp;to complement our qualified workforce of educators. You will be responsible for preparing and implementing a full educational teaching plan according to the school&rsquo;s requirements. It will be fundamental to provide knowledge and instruction to students while also helping them develop their personalities and skills.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		Excellent computer skills and Microsoft Office.</li>\r\n	<li>\r\n		3-5 years of experience.</li>\r\n	<li>\r\n		Excellent command in English</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2017-05-29 09:51:55', '2020-09-16 11:38:46', 0, 0),
(4, 'Key Stage One Teaching Assistant', '<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-size:16px;\"><strong>Description:</strong></span></span></p>\r\n<p>\r\n	<span style=\"color: rgb(69, 69, 69); font-family: Arial, Helvetica, san-serif; font-size: 15px;\">We are seeking Key Stage One Teaching Assistant&nbsp; who will primarily work alongside and supports a classroom teacher.&nbsp;</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong><span style=\"color: rgb(69, 69, 69); font-family: Arial, Helvetica, san-serif; font-size: 15px;\">Qualifications:</span></strong></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		Excellent computer skills.</li>\r\n	<li>\r\n		0-2 years of experience.</li>\r\n	<li>\r\n		Excellent command in English</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2017-05-29 09:52:20', '2020-09-16 11:38:55', 0, 0),
(5, 'There are currently no vacancies available.  If you wish to be considered for any future positions, please send your CV to careers@ethosedu.com', '', '', '2017-10-03 15:49:15', '2018-02-27 08:58:33', 0, 0),
(6, 'Foundation Stage Class Teacher', '<p>\r\n	<strong>Description:</strong></p>\r\n<p>\r\n	Required for Foundation stage to be working as a Class Teacher.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		3-5 years of experience.</li>\r\n	<li>\r\n		Excellent command of English.</li>\r\n	<li>\r\n		Excellent communication and team work skills.</li>\r\n	<li>\r\n		Very good command of Microsoft Office.</li>\r\n</ul>\r\n', 'careers@ethosedu.com ', '2018-02-27 08:59:29', '2020-09-16 11:39:08', 0, 0),
(8, 'Foundation Stage Teacher Assistant', '', 'careers@ethosedu.com', '2018-02-27 09:01:57', '2020-09-28 08:26:03', 0, 0),
(9, 'German Teacher ', '<p>\r\n	<strong>Description:</strong></p>\r\n<p>\r\n	Required for Key Stages a German language Teacher.</p>\r\n<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		ِAlsun German Graduate.</li>\r\n	<li>\r\n		Preferably German high school graduate.</li>\r\n	<li>\r\n		3-5 years of experience.</li>\r\n	<li>\r\n		Good with MS Office.</li>\r\n	<li>\r\n		Good command of English language.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n', 'careers@ethosedu.com', '2018-02-27 09:03:17', '2020-09-16 11:39:33', 0, 0),
(11, 'French Teacher ', '', 'careers@ethosedu.com', '2018-02-27 09:04:33', '2020-09-16 11:40:10', 0, 0),
(12, 'Computing Teacher ', '<p>\r\n	Fluent English is a must&nbsp;</p>\r\n', 'careers@ethosedu.com', '2018-02-27 09:05:45', '2020-09-16 11:40:25', 0, 0),
(13, 'Physical Education Teacher ', '<p>\r\n	<b>Qualifications:</b></p>\r\n<ul>\r\n	<li>\r\n		University Graduate in a relevant discipline.</li>\r\n	<li>\r\n		2-4 years of experience.</li>\r\n	<li>\r\n		Very good command of English language.</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2018-02-27 09:07:43', '2020-09-16 11:40:42', 0, 0),
(15, 'معلم لغة عربية للمرحلة الابتدائية', '<p>\r\n	<strong>Requirments:</strong></p>\r\n<ul>\r\n	<li>\r\n		University Graduate (Arabic Studies).</li>\r\n	<li>\r\n		5-7 years of experience.</li>\r\n	<li>\r\n		Good with MS Office.</li>\r\n	<li>\r\n		Good with Publisher.</li>\r\n	<li>\r\n		Good command of English language.</li>\r\n</ul>\r\n<p>\r\n	&nbsp;</p>\r\n', 'careers@ethosedu.com', '2018-02-27 09:12:09', '2020-05-14 14:17:59', 0, 0),
(17, 'مساعد رئيس قسم الدراسات العربية', '<p>\r\n	<span dir=\"RTL\">امكانيات سكرتارية و فنون</span></p>\r\n', 'careers@ethosedu.com', '2018-02-27 09:14:09', '2019-04-24 12:55:35', 0, 2),
(18, 'معلم تربية اسلامية ', '', 'careers@ethosedu.com', '2019-04-24 13:57:38', '2020-09-16 11:41:01', 0, 0),
(20, 'معلم دراسات إجتماعيه', '<p>\r\n	مؤهل جامعى من أقسام جغرافيا أو تاريخ</p>\r\n<p>\r\n	&nbsp;ما لا يقل عن خمس سنوات خبره.</p>\r\n<p>\r\n	مستوى جيد فى اللغه الإنجليزيه.</p>\r\n<p>\r\n	مستوى جيد فى مهارات MS office و برنامج Publisher.</p>\r\n', 'careers@ethosedu.com', '2019-04-30 11:49:03', '2019-07-09 09:41:04', 0, 0),
(27, 'Math Learning Support Teacher ', '<p>\r\n	2+ years of experience in the same position</p>\r\n', 'careers@ethosedu.com ', '2019-06-01 17:32:26', '2020-09-28 08:25:31', 0, 0),
(28, 'English Learning Support Teacher', '<p>\r\n	<u><strong>Qualifications:</strong></u></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		2+ years experience in the Learning Support teaching field.</li>\r\n	<li>\r\n		Fluent English.</li>\r\n	<li>\r\n		Very good with MS Office.&nbsp;</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2019-06-16 08:49:42', '2020-09-16 11:42:00', 0, 0),
(45, 'Key Stage Two Floating Teacher', '<p>\r\n	<b>Qualifications:</b></p>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	- Minimum of 2 years experience&nbsp;with the same age group in international schools</div>\r\n<div>\r\n	-&nbsp;Perfect spoken and written English</div>\r\n<div>\r\n	- Computer skills: very proficient</div>\r\n<div>\r\n	- preferably teaching diploma holder</div>\r\n<p>\r\n	&nbsp;</p>\r\n', 'careers@ethosedu.com', '2020-05-14 12:14:59', '2021-02-02 09:42:54', 0, 0),
(46, 'Key Stage Two Class Teacher', '<p>\r\n	<strong>Description:</strong></p>\r\n<p>\r\n	We are looking for a committed teacher&nbsp;to complement our qualified workforce of educators. You will be responsible for preparing and implementing a full educational teaching plan according to the school&rsquo;s requirements. It will be fundamental to provide knowledge and instruction to students while also helping them develop their personalities and skills.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		Excellent computer skills and Microsoft Office.</li>\r\n	<li>\r\n		3-5 years of experience.</li>\r\n	<li>\r\n		Excellent command of English</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2020-05-14 12:20:50', '2020-09-16 11:42:16', 0, 0),
(47, 'Key Stage Three Teaching Assistant', '<p>\r\n	<strong>Description:</strong></p>\r\n<p>\r\n	We are seeking Key Stage Three Teaching Assistant who will primarily work alongside and supports a classroom teacher.&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		Excellent computer skills.</li>\r\n	<li>\r\n		1-2 years of experience.</li>\r\n	<li>\r\n		Excellent command in English</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2020-05-14 12:22:03', '2020-09-16 11:46:43', 0, 0),
(48, 'Art Teaching Assistant', '', 'careers@ethosedu.com', '2020-05-14 14:15:08', '2020-09-16 11:42:25', 0, 0),
(49, 'Math Teacher', '<p>\r\n	<strong>Qualifications:</strong></p>\r\n<ul>\r\n	<li>\r\n		University graduate.</li>\r\n	<li>\r\n		Excellent computer skills and Microsoft Office.</li>\r\n	<li>\r\n		3-5 years of experience.</li>\r\n	<li>\r\n		Excellent command of English</li>\r\n</ul>\r\n', 'careers@ethosedu.com', '2020-05-14 14:20:43', '2020-09-16 11:42:36', 0, 0),
(50, 'Junior School Officer', '<p>\r\n	Job Requirements:</p>\r\n<p>\r\n	1. University Graduate</p>\r\n<p>\r\n	2. 0-3 years of experience</p>\r\n<p>\r\n	3. Excellent command of English</p>\r\n<p>\r\n	4. Very good computer skills and Microsoft Office</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', 'careers@ethosedu.com', '2020-06-18 10:43:57', '2020-09-16 11:42:48', 0, 0),
(51, 'Science Teacher', '', '', '2020-08-12 16:06:34', '2020-09-16 11:42:59', 0, 0),
(52, 'Character Education Teacher', '', '', '2020-09-16 11:43:44', '2020-09-28 08:26:49', 0, 1),
(53, 'Rukan Juniors Teacher Assistant', '', '', '2020-09-16 11:44:22', '2020-09-28 08:27:16', 0, 2),
(54, 'Rukan Seniors Teacher Assistant', '', '', '2020-09-16 11:44:41', '2020-09-28 08:27:37', 0, 3),
(55, 'Rukan Toddlers/Infants floating Teacher Assistant', '', '', '2020-09-16 11:45:09', '2020-09-28 08:28:31', 0, 4),
(56, 'HR Admin', '', '', '2020-09-16 11:45:43', '2021-02-02 09:41:57', 0, 5),
(57, 'Year 7 English Teacher', '<ul style=\"list-style: none; margin: 0px; padding-right: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: medium;\">\r\n	<li>\r\n		- University graduate.</li>\r\n	<li>\r\n		- Excellent command in English</li>\r\n	<li>\r\n		- Excellent computer skills and Microsoft Office.</li>\r\n	<li>\r\n		- 3-5 years of experience.</li>\r\n	<li>\r\n		&nbsp;</li>\r\n</ul>\r\n', '', '2020-09-28 08:31:11', '2020-11-08 08:52:07', 0, 0),
(58, 'IG Exam Officer/ Registrar ', '<ul style=\"list-style: none; margin: 0px; padding-right: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: medium;\">\r\n	<li>\r\n		- University graduate.</li>\r\n	<li>\r\n		- Excellent computer skills and Microsoft Office.</li>\r\n	<li>\r\n		- 3-5 years of experience.</li>\r\n	<li>\r\n		- Excellent command in English</li>\r\n</ul>\r\n', '', '2020-09-28 08:32:09', '2021-02-02 09:42:34', 0, 0),
(59, 'Acountant ', '<div>\r\n	- Experience: 0-5 years&nbsp;</div>\r\n<div>\r\n	- Preferably&nbsp;accounting graduate</div>\r\n<div>\r\n	- Very good spoken and written English</div>\r\n<div>\r\n	- Preferably Sheikh Zayed or October resident</div>\r\n', 'careers@ethosedu.com', '2020-10-28 18:00:15', '2020-11-08 08:52:22', 0, 0),
(60, 'Ethos Academy Coordinator', '<div>\r\n	<div>\r\n		<strong>Description</strong>:</div>\r\n	<div>\r\n		&nbsp;</div>\r\n	<div>\r\n		<u>Gender</u>: Male or Female</div>\r\n	<div>\r\n		<u>Working hours:</u>&nbsp;from 2:30 pm to 6:30 pm except Wednesday:&nbsp;&nbsp; from 12:30 pm to 6:30 pm</div>\r\n</div>\r\n<div>\r\n	Fresh graduates and Undergraduates are welcome to apply</div>\r\n', '', '2020-11-08 08:55:28', '2021-02-02 09:42:16', 0, 0),
(61, 'Academic Administrator ', '<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp; Requirements:</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- 2 to 5 years experience in the administration&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Experience in the education&nbsp;field is preferred</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Very good computer skills&nbsp;&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Excellent&nbsp;spoken and written English</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Excellent communication skills&nbsp;</div>\r\n', 'careers@ethosedu.com', '2021-02-04 14:23:09', '2021-02-04 14:24:57', 1, 1),
(62, 'MFL Coordinator - French', '<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp; &nbsp; &nbsp;Requirements:</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- 10+ years teaching experience&nbsp;is a must</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- French School graduate is preferred</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Faculty of ElAlson&nbsp;- French Department is preferred&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Teaching Diploma&nbsp;is a must&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Very good computer skills&nbsp;&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Excellent&nbsp;spoken and written French</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	&nbsp;- Good command of spoken and written English</div>\r\n', '', '2021-02-17 16:44:22', '2021-02-17 16:45:38', 1, 0),
(63, 'MFL Coordinator - German', '<div>\r\n	Requirements:</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	- 10+ years teaching experience&nbsp;is a must</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div>\r\n	- German School graduate is preferred</div>\r\n<div>\r\n	- Faculty of ElAlson&nbsp;- German Department is preferred&nbsp;</div>\r\n<div>\r\n	- Teaching Diploma&nbsp;is a must&nbsp;</div>\r\n<div>\r\n	- Very good computer skills&nbsp;&nbsp;</div>\r\n<div>\r\n	- Excellent&nbsp;spoken and written German</div>\r\n<div>\r\n	- Good command of spoken and written English</div>\r\n<div>\r\n	&nbsp;</div>\r\n<div style=\"font-family: Arial, Helvetica, sans-serif; font-size: small;\">\r\n	<div data-smartmail=\"gmail_signature\" dir=\"ltr\">\r\n		&nbsp;</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '', '2021-02-17 16:46:58', '2021-02-19 02:59:40', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL DEFAULT '#000000',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `color`, `approved`, `created`, `updated`, `weight`) VALUES
(1, 'Sports', '#009933', 1, '2015-11-11 05:58:06', '2015-11-26 11:29:49', 0),
(2, 'Holiday', '#ff0033', 1, '2015-11-11 05:58:30', '2015-11-26 11:30:03', 0),
(3, 'Academic', '#3300ff', 1, '2015-11-11 21:44:02', '2015-11-26 11:30:15', 0),
(4, 'Open Day', '#00cccc', 1, '2015-11-11 21:44:26', '2015-11-26 11:30:40', 0),
(5, 'Trips', '#6633cc', 1, '2015-11-11 21:44:46', '2015-11-26 11:30:49', 0),
(6, 'Parents Day', '#cc9966', 1, '2015-11-25 08:05:20', '2015-11-26 11:31:10', 0),
(7, 'Other', '#660000', 0, '2015-11-26 11:29:37', '2015-11-26 11:29:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE `cats` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `cat_type` int NOT NULL DEFAULT '0',
  `parent_id` int DEFAULT '0',
  `date` date NOT NULL,
  `under_construction` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int DEFAULT '0',
  `has_url` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) DEFAULT NULL,
  `pdf_file` varchar(255) DEFAULT NULL,
  `to_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`id`, `title`, `body`, `image`, `meta_keywords`, `meta_description`, `cat_type`, `parent_id`, `date`, `under_construction`, `approved`, `created`, `updated`, `weight`, `has_url`, `url`, `pdf_file`, `to_email`) VALUES
(23, 'Online Admission Form', '', '', '', '', 0, NULL, '0000-00-00', 0, 1, '2015-11-13 01:43:31', '2022-01-07 23:36:45', 3, 0, '', '', 'admission.online.forms@ethosedu.com');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `article_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `map_iframe` longtext,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `facebook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `working_hours` text,
  `inner_title` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `zoom` int NOT NULL DEFAULT '17'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `title`, `body`, `map_iframe`, `address`, `phone`, `mail`, `facebook_link`, `linkedin_link`, `working_hours`, `inner_title`, `latitude`, `longitude`, `zoom`) VALUES
(1, 'Contact Us', '<p>\r\n	<span style=\"font-size:24px;\">Contact Details</span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<span style=\"font-size:16px;\"><strong>Address:</strong> </span>20/6 behind Royal City Compound, Sheikh Zayed City, Egypt.</p>\r\n<p>\r\n	&nbsp;</p>\r\n<h3>\r\n	<span style=\"font-size:16px;\"><strong>Mobile Numbers:</strong></span></h3>\r\n<p>\r\n	01028966660</p>\r\n<p>\r\n	01028966663</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>Email:</strong> info@ethosedu.com</p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>General Departments:</strong></p>\r\n<p>\r\n	admission@ethosedu.com</p>\r\n<p>\r\n	finance@ethosedu.com</p>\r\n<p>\r\n	careers@ethosedu.com</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1726.7967341989813!2d30.990038671900187!3d30.048518805670664!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sar!2seg!4v1448323659808\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>', '20/6 behind Royal City compound, Sheikh Zayed City, Cairo', '(+2) 01028966660', 'info@ethosedu.com', 'https://www.facebook.com/ethosinternationalschool', 'http://www.linkedin.com/LCEofficial', '<p>\r\n	Sunday-Thursday: 10am to 10pm<br />\r\n	Friday: 3pm to 9pm<br />\r\n	Satuday: Closed</p>\r\n', 'Send us a message', '30.039669931708485', '31.0542618126526', 13);

-- --------------------------------------------------------

--
-- Table structure for table `developments`
--

CREATE TABLE `developments` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `developments`
--

INSERT INTO `developments` (`id`, `title`, `sub_title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(2, 'Classroom Centers', 'Training & Workshops', '<p>\r\n	<span style=\"font-size:12px;\"><span style=\"color: rgb(51, 51, 51); font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 20px;\">A learning center is a self-contained section of the classroom in which students engage in independent and self-directed learning activities. They&nbsp;</span><span style=\"color: rgb(51, 51, 51); font-family: \'Helvetica Neue\', Helvetica, Arial, sans-serif; line-height: 20px;\">give teachers the opportunity to focus on specific areas of study and adhere to learning interaction between pupils.&nbsp;</span></span>Centers help in creating effective classroom centers that help and facilitate the delivery of the learning objectives.</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '20151109022338_2f1c5.jpg', '2015-11-20 06:58:53', '2015-12-07 14:31:11', 2, 1),
(3, 'Guided Reading', 'Training & Workshops', '<p>\r\n	Guided reading is the bridge between shared (group) reading and independent reading. It allows teachers to help pupils make the transition from teacher modelling to pupils&#39; independence. In guided reading, the teacher scaffolds the learning of a small group of pupils as they apply strategies previously taught during read-alouds and shared reading to an unfamiliar, but carefully selected, text. This text is within the pupils&#39; instructional range and provides reasonable challenges for learning. The teacher supports the pupils as they talk, read, and think their way through a text using effective reading strategies. While the teacher works with a guided reading group, the rest of the class engages in independent activities. From the first few weeks of school, the teacher provides many opportunities for pupils to practice learning center routines before working independently in small groups.</p>\r\n', 'IMG_5036.JPG_73868.jpg', '2015-11-20 06:59:24', '2015-12-07 10:55:46', 3, 1),
(4, 'Jolly Phonics', 'Training & Workshops', '<p>\r\n	It is a comprehensive 2 day programme that provides optimum coverage of theory and practice in teaching Phonics. The entire course is based on Jolly Phonics Methodology and is delivered by professional Jolly Phonics trainers accredited by Jolly Learning Ltd of UK, the original developers of the Jolly Phonics Methodology. The workshop covers topics that are essential for every teacher.&nbsp;At Ethos we use the Jolly Phonics program; which has a fun and child centered approach to teaching literacy through synthetic phonics. With actions for each of the 42 letter sounds, the multi-sensory method is very motivating for children. The sounds are taught in a specific order (not alphabetically). This enables children to begin building words as early as possible.</p>\r\n', '20151109022819_95161.jpg', '2015-11-20 06:59:49', '2015-12-07 14:31:03', 1, 1),
(5, 'Emergency First Response', 'Trainings & Workshops', '<p>\r\n	Our PE staff have attended the Emergency First Response training. The training aims to provide rescuers with the tools needed to perform life support and first aid when faced with any medical emergency.<span style=\"font-size:14px;\">&nbsp;<span style=\"font-size:12px;\"><span style=\"color: rgb(36, 36, 36); font-family: \'Source Sans Pro\', sans-serif; line-height: 24.2857px;\">This course allows participants to learn, practice and apply emergency care skills specific to helping infants and children with medical emergencies. It&rsquo;s designed for those who work with children or are likely to have to respond to emergencies involving youngsters. This course is often integrated with Primary Care (CPR) and Secondary Care (First Aid) courses.</span></span></span></p>\r\n', 'Emergency_First_Response_d0fe8.jpg', '2015-12-07 10:30:06', '2015-12-07 14:31:24', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `disclaimers`
--

CREATE TABLE `disclaimers` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `disclaimers`
--

INSERT INTO `disclaimers` (`id`, `title`, `body`) VALUES
(1, 'Disclaimer', '<p>\r\n	<span style=\"font-size:16px;\"><span>Please make sure you have the soft copies of the following documents before you attempt to complete the online application form:</span></span></p>\r\n<ul>\r\n	<li style=\"display: list-item;\">\r\n		<span style=\"font-size:16px;\"><span>Child&rsquo;s recent photo (passport size)</span></span></li>\r\n	<li style=\"display: list-item;\">\r\n		<span style=\"font-size:16px;\"><span>Child&rsquo;s birth certificate (electronic)</span></span></li>\r\n	<li style=\"display: list-item;\">\r\n		<span style=\"font-size:16px;\"><span>Parents IDs</span></span></li>\r\n	<li style=\"display: list-item;\">\r\n		<span style=\"font-size:16px;\"><span>Most recent school reports (<u><strong>Not </strong></u>required from pupils applying to <b>Preschool</b> or <b>Foundation Stage 1</b>)</span></span></li>\r\n</ul>\r\n<p>\r\n	<span style=\"font-size:16px;\"><span>Kindly note that only completed and qualified application forms will be considered.</span></span></p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `identifier` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `title`, `body`, `identifier`) VALUES
(1, 'Notification', '<p>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Dear {{name}}, </span></span></p>\r\n<p>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">Thank you for applying at Ethos International School. Please note that your application will become active only after all of the essential supporting documents are reviewed. You will receive a confirmation email shortly, application number {{application_number}}</span></span></p>\r\n', 'notification'),
(2, 'Notification for admin', '<p>\r\n	<span style=\"font-family: verdana, geneva, sans-serif; font-size: 16px;\">Dear</span><span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">&nbsp;{{name}}, </span></span></p>\r\n<p>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">There is a pending application with number {{application_number}}, check it.</span></span></p>\r\n', 'notification_admin'),
(3, 'Confirmation Email- Accepted', '<div>\r\n	<span style=\"font-family: verdana, geneva, sans-serif; font-size: 16px;\">Dear</span><span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">&nbsp;{{name}},</span></span></div>\r\n<p>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">We welcome your interest in Ethos International School. This is to confirm that your application form is accepted, you can expect to receive a call from a member of the admissions team to invite your child to attend an entrance assessment, application&nbsp;number {{application_number}}</span></span></p>\r\n', 'confirmation-accepted'),
(4, 'Confirmation Email- Rejected', '<div>\r\n	<span style=\"font-family: verdana, geneva, sans-serif; font-size: 16px;\">Dear</span><span style=\"font-size:16px;\">&nbsp;{{name}},</span></div>\r\n<p>\r\n	<span style=\"font-size:16px;\">Your application with number {{application_number}} has been rejected.</span></p>\r\n', 'confirmation-rejected'),
(5, 'Confirmation Email- Resubmitted', '<div>\r\n	<span style=\"font-size:16px;\">Dear {{name}},</span></div>\r\n<div>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:verdana,geneva,sans-serif;\">We welcome your interest in Ethos International School. This is to confirm that your application form submitted is missing essential supporting documents; you need to resubmit the following by sending an email to&nbsp;<a href=\"mailto:admission.online.forms@ethosedu.com\">admission.online.forms@ethosedu.com</a>.</span></span></div>\r\n<div>\r\n	<span style=\"font-size:16px;\">{{checklist}}</span></div>\r\n<div>\r\n	<span style=\"font-size:16px;\">Upon submission, we will be receiving a confirmation email that your application form is active.</span></div>\r\n<div>\r\n	<span style=\"font-family: verdana, geneva, sans-serif; font-size: 16px;\">application&nbsp;number {{application_number}}</span></div>\r\n', 'confirmation-resubmitted');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int NOT NULL,
  `title` text NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `timing` time NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `agenda` longtext,
  `member_id` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `category_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `from_date`, `to_date`, `timing`, `location`, `agenda`, `member_id`, `created`, `updated`, `approved`, `category_id`) VALUES
(115, '<p>\r\n	First Day for Foundation Stage 1 Y3 &amp; Y4</p>\r\n', '2019-09-03', '2019-09-03', '08:00:00', '', '', 0, '2018-09-19 12:34:45', '2020-01-27 14:42:19', 1, 3),
(116, '<p>\r\n	First Day for Foundation Stage 2 and Key Stage 1&nbsp;</p>\r\n', '2019-09-04', '2019-09-04', '08:00:00', '', '', 0, '2018-09-19 12:35:25', '2020-01-27 14:43:07', 1, 3),
(117, '<p>\r\n	First Day of Term</p>\r\n', '2020-01-12', '2020-01-12', '18:00:00', '', '', 0, '2018-09-19 12:36:06', '2020-01-27 14:54:47', 1, 3),
(118, '<p>\r\n	ECA&#39;s Starts</p>\r\n', '2020-01-29', '2020-01-29', '18:00:00', '', '', 0, '2018-09-19 12:36:54', '2020-01-27 14:56:08', 1, 7),
(119, '<p>\r\n	ECA&#39;s Ends</p>\r\n', '2020-03-11', '2020-03-11', '18:00:00', '', '', 0, '2018-09-19 12:37:34', '2020-01-27 14:58:27', 1, 7),
(120, '<p>\r\n	Armed Forces Day&nbsp;</p>\r\n', '2019-10-06', '2019-10-06', '08:00:00', '', '', 0, '2018-09-19 12:51:41', '2020-01-27 14:45:19', 1, 2),
(121, '<p>\r\n	Half Term Holiday&nbsp;</p>\r\n', '2019-10-27', '0000-00-00', '08:00:00', '', '', 0, '2018-09-19 12:52:44', '2020-01-27 14:48:56', 1, 2),
(122, '<p>\r\n	Prophet&#39;s Birthday&nbsp;</p>\r\n', '2019-11-10', '2019-11-10', '08:00:00', '', '', 0, '2018-09-19 12:53:14', '2020-01-27 14:51:28', 1, 2),
(123, '<p>\r\n	Winter Break&nbsp;</p>\r\n', '2019-12-22', '2020-01-09', '08:00:00', '', '', 0, '2018-09-19 12:54:12', '2020-01-27 14:53:28', 1, 2),
(124, '<p>\r\n	Parents Day&nbsp;</p>\r\n', '2019-11-07', '2019-11-07', '08:00:00', '', '', 0, '2018-09-19 12:54:48', '2020-01-27 14:50:57', 1, 6),
(125, '<p>\r\n	Police/ Revolution Day&nbsp;</p>\r\n', '2020-01-25', '2020-01-25', '08:00:00', '', '', 0, '2018-09-19 12:55:22', '2020-01-27 14:55:06', 1, 2),
(126, '<p>\r\n	Half Term Holiday&nbsp;</p>\r\n', '2020-02-23', '2020-02-27', '08:00:00', '', '', 0, '2018-09-19 12:56:10', '2020-01-27 14:57:40', 1, 2),
(127, '<p>\r\n	Parents Day&nbsp;</p>\r\n', '2020-02-16', '2020-02-16', '08:00:00', '', '', 0, '2018-09-19 12:57:14', '2020-01-27 14:57:03', 1, 6),
(128, '<p>\r\n	Spring Break&nbsp;</p>\r\n', '2020-04-12', '2020-05-23', '08:00:00', '', '', 0, '2018-09-19 12:57:54', '2020-01-27 14:59:16', 1, 2),
(129, '<p>\r\n	Eid El Fitr Holiday&nbsp;</p>\r\n', '2020-05-24', '2020-05-28', '08:00:00', '', '', 0, '2018-09-19 12:58:37', '2020-01-27 15:02:18', 1, 2),
(130, '<p>\r\n	Last Day For Foundation Stage Pupils&nbsp;</p>\r\n', '2020-06-18', '2020-06-18', '08:00:00', '', '', 0, '2018-09-19 12:59:25', '2020-01-27 15:04:03', 1, 3),
(131, '<p>\r\n	Last Day For Key Stages</p>\r\n', '2020-06-23', '2020-06-23', '08:00:00', '', '', 0, '2018-09-19 13:00:09', '2020-01-27 15:04:22', 1, 3),
(132, '<p>\r\n	First Day Y5, Y6 &amp; KS3</p>\r\n', '2019-09-08', '2019-09-08', '08:00:00', '', '', 0, '2020-01-27 14:44:16', '2020-01-27 14:45:37', 1, 3),
(133, '<p>\r\n	ECA&#39;s Starts</p>\r\n', '2019-10-02', '2019-10-02', '08:00:00', '', '', 0, '2020-01-27 14:47:10', '2020-01-27 14:47:10', 1, 7),
(134, '<p>\r\n	ECA&#39;s Ends</p>\r\n', '2019-11-13', '2019-11-13', '08:00:00', '', '', 0, '2020-01-27 14:52:31', '2020-01-27 14:52:31', 1, 7),
(135, '<p>\r\n	Ramadan Starts</p>\r\n', '2020-04-24', '2020-04-24', '08:00:00', '', '', 0, '2020-01-27 15:00:04', '2020-01-27 15:00:04', 1, 7),
(136, '<p>\r\n	First Day of Term</p>\r\n', '2020-04-26', '2020-04-26', '08:00:00', '', '', 0, '2020-01-27 15:01:16', '2020-01-27 15:01:16', 1, 3),
(137, '<p>\r\n	Readopedia Starts</p>\r\n', '2020-02-02', '2020-02-02', '08:00:00', '', '<p>\r\n	School reading event</p>\r\n', 0, '2020-01-29 13:21:30', '2020-01-29 13:21:30', 1, 3),
(138, '<p>\r\n	Readopedia Camp In</p>\r\n', '2020-02-13', '2020-02-13', '08:00:00', '', '<p>\r\n	From Year 5 to Year 9</p>\r\n', 0, '2020-01-29 13:26:27', '2020-01-29 13:26:27', 1, 3),
(139, '<p>\r\n	Readopedia Ends</p>\r\n', '2020-02-13', '2020-02-13', '08:00:00', '', '', 0, '2020-01-29 13:27:14', '2020-01-29 13:27:14', 1, 3),
(140, '<p>\r\n	Mufti Day</p>\r\n', '2020-02-20', '2020-02-20', '08:00:00', '', '', 0, '2020-01-29 13:28:40', '2020-01-29 13:28:40', 1, 3),
(141, '<p>\r\n	Rukarnival</p>\r\n', '2020-02-21', '2020-02-21', '08:00:00', '', '', 0, '2020-01-29 13:32:58', '2020-01-29 13:32:58', 1, 7),
(142, '<p>\r\n	Matholympics</p>\r\n', '2020-03-15', '2020-03-16', '08:00:00', '', '', 0, '2020-01-29 13:35:28', '2020-01-29 13:35:28', 1, 3),
(143, '<p>\r\n	Mother&#39;s Day / Themed Mufti Day</p>\r\n', '2020-03-19', '2020-03-19', '08:00:00', '', '', 0, '2020-01-29 13:36:17', '2020-01-29 13:36:17', 1, 7),
(144, '<p>\r\n	KS2 &amp; 3 Etholympics</p>\r\n', '2020-03-29', '2020-03-29', '08:00:00', '', '', 0, '2020-01-29 13:42:38', '2020-01-29 13:42:38', 1, 1),
(145, '<p>\r\n	Art Exhibition</p>\r\n', '2020-06-03', '2020-06-03', '08:00:00', '', '', 0, '2020-01-29 13:44:59', '2020-01-29 13:44:59', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `forum_comments`
--

CREATE TABLE `forum_comments` (
  `id` int NOT NULL,
  `comment` longtext NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(255) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `member_id` int NOT NULL DEFAULT '0',
  `post_id` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `gals`
--

CREATE TABLE `gals` (
  `id` int NOT NULL,
  `caption` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `node_id` int NOT NULL DEFAULT '0',
  `content_id` int NOT NULL DEFAULT '0',
  `position` int NOT NULL DEFAULT '0',
  `article_id` int NOT NULL DEFAULT '0',
  `album_id` int NOT NULL DEFAULT '0',
  `cover` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `gals`
--

INSERT INTO `gals` (`id`, `caption`, `image`, `node_id`, `content_id`, `position`, `article_id`, `album_id`, `cover`) VALUES
(430, '', '/2019/12/IMG-20190912-WA0111.jpg', 0, 0, 0, 0, 19, 0),
(431, '', '/2019/12/IMG-20190912-WA0109.jpg', 0, 0, 0, 0, 19, 0),
(432, '', '/2019/12/IMG-20190912-WA0025.jpg', 0, 0, 0, 0, 19, 0),
(433, '', '/2019/12/IMG-20190912-WA0067.jpg', 0, 0, 0, 0, 19, 1),
(434, '', '/2019/12/IMG_6411.jpg', 0, 0, 0, 0, 20, 0),
(435, '', '/2019/12/DSC_4524.jpg', 0, 0, 0, 0, 20, 0),
(436, '', '/2019/12/IMG_6208.jpg', 0, 0, 0, 0, 20, 0),
(437, '', '/2019/12/DSC_4445.jpg', 0, 0, 0, 0, 20, 0),
(438, '', '/2019/12/DSC_4539.jpg', 0, 0, 0, 0, 20, 0),
(439, '', '/2019/12/DSC_4486.jpg', 0, 0, 0, 0, 20, 0),
(440, '', '/2019/12/DSC_4541.jpg', 0, 0, 0, 0, 20, 0),
(441, '', '/2019/12/IMG_5653.jpg', 0, 0, 0, 0, 20, 0),
(442, '', '/2019/12/IMG_6236.jpg', 0, 0, 0, 0, 20, 0),
(443, '', '/2019/12/DSC_4531.jpg', 0, 0, 0, 0, 20, 0),
(444, '', '/2019/12/IMG_6414.jpg', 0, 0, 0, 0, 20, 0),
(445, '', '/2019/12/IMG_6370.jpg', 0, 0, 0, 0, 20, 0),
(446, '', '/2019/12/IMG_6358.jpg', 0, 0, 0, 0, 20, 0),
(447, '', '/2019/12/DSC_4364.jpg', 0, 0, 0, 0, 20, 0),
(448, '', '/2019/12/1576754447DSC_4348.jpg', 0, 0, 0, 0, 20, 1),
(449, '', '/2019/12/6B5A9608-2.jpg', 0, 0, 0, 0, 21, 0),
(450, '', '/2019/12/6B5A9605-2.jpg', 0, 0, 0, 0, 21, 0),
(451, '', '/2019/12/6B5A9628-2.jpg', 0, 0, 0, 0, 21, 0),
(452, '', '/2019/12/6B5A9636-2.jpg', 0, 0, 0, 0, 21, 0),
(453, '', '/2019/12/6B5A9599-2.jpg', 0, 0, 0, 0, 21, 0),
(454, '', '/2019/12/6B5A9575-2.jpg', 0, 0, 0, 0, 21, 0),
(455, '', '/2019/12/6B5A9629-2.jpg', 0, 0, 0, 0, 21, 0),
(456, '', '/2019/12/6B5A9637-2.jpg', 0, 0, 0, 0, 21, 1),
(457, '', '/2019/12/6B5A9602-2.jpg', 0, 0, 0, 0, 21, 0),
(458, '', '/2019/12/6B5A9579-2.jpg', 0, 0, 0, 0, 21, 0),
(459, '', '/2019/12/6B5A9606-2.jpg', 0, 0, 0, 0, 21, 0),
(460, '', '/2019/12/6B5A9634-2.jpg', 0, 0, 0, 0, 21, 0),
(461, '', '/2019/12/6B5A9644-2.jpg', 0, 0, 0, 0, 21, 0),
(462, '', '/2019/12/6B5A9649-2.jpg', 0, 0, 0, 0, 21, 0),
(463, '', '/2019/12/6B5A9627-2.jpg', 0, 0, 0, 0, 21, 0),
(464, '', '/2019/12/6B5A9642-2.jpg', 0, 0, 0, 0, 21, 0),
(465, '', '/2019/12/6B5A9626-2.jpg', 0, 0, 0, 0, 21, 0),
(466, '', '/2019/12/6B5A9623-2.jpg', 0, 0, 0, 0, 21, 0),
(467, '', '/2019/12/6B5A9587-2.jpg', 0, 0, 0, 0, 21, 0),
(468, '', '/2019/12/6B5A9592-2.jpg', 0, 0, 0, 0, 21, 0),
(484, '', '/2021/01/1612025571Ethos_-_Gymnastics_hall_6.jpg', 0, 0, 0, 0, 22, 0),
(485, '', '/2021/01/1612025575Ethos_-_Classroom_4.jpg', 0, 0, 0, 0, 22, 0),
(486, '', '/2021/01/1612025576Ethos_Library_5.jpg', 0, 0, 0, 0, 22, 0),
(487, '', '/2021/01/1612025576Ethos_-_Gymnastics_hall_4.jpg', 0, 0, 0, 0, 22, 0),
(488, '', '/2021/01/1612025577Ethos_-_Classroom_1.jpg', 0, 0, 0, 0, 22, 0),
(489, '', '/2021/01/1612025577Ethos_Library_3.jpg', 0, 0, 0, 0, 22, 0),
(490, '', '/2021/01/1612025578Ethos_MP_Room_5.jpg', 0, 0, 0, 0, 22, 0),
(491, '', '/2021/01/1612025578Ethos_-_Gymnastics_hall_3.jpg', 0, 0, 0, 0, 22, 0),
(492, '', '/2021/01/1612025579Ethos_Library_1.jpg', 0, 0, 0, 0, 22, 0),
(493, '', '/2021/01/1612025579Ethos_-_Gymnastics_hall_5.jpg', 0, 0, 0, 0, 22, 0),
(494, '', '/2021/01/1612025580Ethos_Library_2.jpg', 0, 0, 0, 0, 22, 0),
(495, '', '/2021/01/1612025580Ethos_-_MP_Court_3.jpg', 0, 0, 0, 0, 22, 0),
(496, '', '/2021/01/1612025580Ethos_Library_4.jpg', 0, 0, 0, 0, 22, 0),
(497, '', '/2021/01/1612025583Ethos_-_Resources_room_4.jpg', 0, 0, 0, 0, 22, 0),
(498, '', '/2021/01/1612025585Ethos_MP_Room_4.jpg', 0, 0, 0, 0, 22, 0),
(499, '', '/2021/01/1612025585Ethos_MP_Room_3.jpg', 0, 0, 0, 0, 22, 0),
(500, '', '/2021/01/1612025589Ethos_-_MP_Court_2.jpg', 0, 0, 0, 0, 22, 0),
(501, '', '/2021/01/1612025589Ethos_-_Gym_Boys_2.jpg', 0, 0, 0, 0, 22, 0),
(502, '', '/2021/01/1612025591Ethos_-_MP_Court_1.jpg', 0, 0, 0, 0, 22, 0),
(503, '', '/2021/01/1612025591Ethos_-_Classroom_3.jpg', 0, 0, 0, 0, 22, 0),
(504, '', '/2021/01/1612025591Ethos_MP_Room_1.jpg', 0, 0, 0, 0, 22, 0),
(505, '', '/2021/01/1612025592Ethos_-_Gymnastics_hall_2.jpg', 0, 0, 0, 0, 22, 0),
(506, '', '/2021/01/1612025592Ethos_-_Gymnastics_hall_1.jpg', 0, 0, 0, 0, 22, 0),
(507, '', '/2021/01/1612025592Ethos_-_Pool_Boys_3.jpg', 0, 0, 0, 0, 22, 0),
(508, '', '/2021/01/1612025592Ethos_MP_Room_2.jpg', 0, 0, 0, 0, 22, 0),
(509, '', '/2021/01/1612025592Ethos_-_Resources_room_3.jpg', 0, 0, 0, 0, 22, 0),
(510, '', '/2021/01/1612025592Ethos_-_Pool_Boys_1.jpg', 0, 0, 0, 0, 22, 0),
(511, '', '/2021/01/1612025592Ethos_-_Classroom_2.jpg', 0, 0, 0, 0, 22, 0),
(512, '', '/2021/01/1612025592Ethos_-_Pool_Boys_4.jpg', 0, 0, 0, 0, 22, 0),
(513, '', '/2021/01/1612025593Ethos_-_Resources_room_1.jpg', 0, 0, 0, 0, 22, 0),
(514, '', '/2021/01/1612025593Ethos_-_Pool_Boys_2.jpg', 0, 0, 0, 0, 22, 0),
(515, '', '/2021/01/1612025593Ethos_-_Resources_room_2.jpg', 0, 0, 0, 0, 22, 0),
(516, '', '/2021/01/1612025593Ethos_-_Gym_Boys__1.jpg', 0, 0, 0, 0, 22, 0),
(517, '', '/2021/01/1612025600Ethos_-_MP_Court_4.jpg', 0, 0, 0, 0, 22, 0);

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE `logos` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `weight` int DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `role` int NOT NULL DEFAULT '2',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `block_posts_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_comments_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_announcements_notification` tinyint(1) NOT NULL DEFAULT '0',
  `block_events_notification` tinyint(1) NOT NULL DEFAULT '0',
  `confirm_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

CREATE TABLE `newsletters` (
  `id` int NOT NULL,
  `from_name` varchar(255) DEFAULT NULL,
  `from_email` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE `nodes` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `teaser` text NOT NULL,
  `body` longtext NOT NULL,
  `viewed` int NOT NULL DEFAULT '0',
  `created` date NOT NULL,
  `updated` date NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` int NOT NULL DEFAULT '0',
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `date` date NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `participants` int DEFAULT NULL,
  `weight` int DEFAULT '0',
  `top_image` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `orientations`
--

CREATE TABLE `orientations` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `orientations`
--

INSERT INTO `orientations` (`id`, `title`, `body`, `start_date`, `end_date`, `approved`, `url`) VALUES
(1, 'Virtual Orientation Announcement', '<div style=\"text-align: center;\">\r\n	<p>\r\n		Do you want to take a look inside our school from the comfort of your home? Nothing can beat a face-to-face tour, but a virtual experience is the next best thing.</p>\r\n	<p>\r\n		You are warmly invited to our virtual orientation and school tour from the comfort of your home. We hope that you get a good flavor of the happy, sincere and welcoming school that Ethos is proud to be.</p>\r\n	<p>\r\n		Register now for our virtual orientation and school tour, fill in the short form and we will send you an email with the needed details.</p>\r\n	<p align=\"center\">\r\n		<a href=\"https://docs.google.com/forms/d/e/1FAIpQLSd87BjMe-_rZAL3eNVRCRXoA5zCDmJLo5TYppA89seE6lGnkA/viewform\">Ethos International School Virtual Orientation Registration Form</a></p>\r\n	<p>\r\n		Stay home, stay safe!</p>\r\n	<p>\r\n		&nbsp;</p>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '2021-01-05', '2021-05-02', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` longtext,
  `image` varchar(255) DEFAULT NULL,
  `video` varchar(355) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `category_id` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `member_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `queues`
--

CREATE TABLE `queues` (
  `id` int NOT NULL,
  `newsletter_id` int NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `body` text,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `data` longblob NOT NULL,
  `application_number` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int NOT NULL,
  `url` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `file_types` varchar(255) NOT NULL,
  `image_types` varchar(255) NOT NULL,
  `max_upload_size` int NOT NULL,
  `resize` int NOT NULL,
  `max_image_width` int NOT NULL,
  `master_image_width` int NOT NULL,
  `master_image_height` int NOT NULL,
  `large_image_width` int NOT NULL,
  `large_image_height` int NOT NULL,
  `medium_image_width` int NOT NULL,
  `medium_image_height` int NOT NULL,
  `thumb_width` int NOT NULL,
  `thumb_height` int NOT NULL,
  `video_width` int NOT NULL,
  `video_height` int NOT NULL,
  `limit` int NOT NULL DEFAULT '0',
  `google_analytics_propertyid` varchar(255) NOT NULL,
  `audio_width` int NOT NULL,
  `audio_height` int NOT NULL,
  `facbook_link` varchar(255) DEFAULT NULL,
  `linkedin_link` varchar(255) DEFAULT NULL,
  `youtube_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL,
  `google_plus_link` varchar(255) DEFAULT NULL,
  `contact_us_email` varchar(255) NOT NULL,
  `paging_limit` int NOT NULL DEFAULT '12',
  `minimum_year` int NOT NULL,
  `maximum_year` int NOT NULL,
  `newsletter_limit` int NOT NULL,
  `return_path_email` varchar(255) NOT NULL,
  `comment_paging_limit` int NOT NULL DEFAULT '0',
  `home_string` varchar(255) NOT NULL,
  `blog_string` varchar(255) NOT NULL,
  `faq_string` varchar(255) NOT NULL,
  `faq_fotter_string` varchar(255) NOT NULL,
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_mode_text` text,
  `testimonial_cut_string` int NOT NULL DEFAULT '0',
  `article_cut_string` int NOT NULL DEFAULT '0',
  `article_cut_string_inner` int NOT NULL DEFAULT '0',
  `gallary_paging_limit` int NOT NULL DEFAULT '0',
  `carrers_paging_limit` int NOT NULL DEFAULT '0',
  `carrers_developments_paging_limit` int NOT NULL DEFAULT '0',
  `vacancies_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `url`, `email`, `title`, `footer`, `meta_keywords`, `meta_description`, `file_types`, `image_types`, `max_upload_size`, `resize`, `max_image_width`, `master_image_width`, `master_image_height`, `large_image_width`, `large_image_height`, `medium_image_width`, `medium_image_height`, `thumb_width`, `thumb_height`, `video_width`, `video_height`, `limit`, `google_analytics_propertyid`, `audio_width`, `audio_height`, `facbook_link`, `linkedin_link`, `youtube_link`, `twitter_link`, `google_plus_link`, `contact_us_email`, `paging_limit`, `minimum_year`, `maximum_year`, `newsletter_limit`, `return_path_email`, `comment_paging_limit`, `home_string`, `blog_string`, `faq_string`, `faq_fotter_string`, `maintenance_mode`, `maintenance_mode_text`, `testimonial_cut_string`, `article_cut_string`, `article_cut_string_inner`, `gallary_paging_limit`, `carrers_paging_limit`, `carrers_developments_paging_limit`, `vacancies_url`) VALUES
(1, 'http://localhost/myworkspace/ethos', 'ethos@mohamedelsayed.net', 'Ethos', '© All Copyrights Reserved. 2015', '', '', 'zip,rar,pdf,doc,docx,flv,mp3,xls,xlsx,ppt,pptx', 'jpeg,jpg,gif,png', 2000, 4, 2000, 800, 500, 705, 342, 385, 250, 250, 250, 500, 300, 80, 'UA-73581303-1', 400, 27, 'https://www.facebook.com/EthosInternationalSchool/', 'http://www.linkedin.com/', 'http://www.youtube.com/', 'http://twitter.com/', 'http://plus.google.com/', 'lce@mohamedelsayed.net', 4, 1900, 2020, 100, 'ethos@mohamedelsayed.net', 10, 'Home', 'Blog', 'FAQS', 'FAQS in coaching', 0, '<p style=\"text-align: center;\">\r\n	&nbsp;</p>\r\n<p style=\"text-align: center;\">\r\n	This site is under construction.</p>\r\n', 30, 13, 20, 9, 4, 4, 'https://goo.gl/forms/ndchureWzCsD1TJv1');

-- --------------------------------------------------------

--
-- Table structure for table `slideshows`
--

CREATE TABLE `slideshows` (
  `id` int NOT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `target` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `name`, `email`, `phone`, `job`, `created`, `updated`, `sent`, `user_id`) VALUES
(1, NULL, 'me@mohamedelsayed.net', NULL, NULL, '2015-11-21 09:25:33', '2015-11-21 09:25:33', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `biography` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `name`, `position`, `biography`, `image`, `mail`, `linkedin`, `created`, `updated`, `type`, `approved`, `weight`) VALUES
(7, 'Muhammad Salah', 'General Manager', '<p>\r\n	<span style=\"font-size:16px;\">Mr. Salah graduated from the Faculty of Engineering at the University of Alexandria. He started his career by founding a construction company and an agricultural company for exports. He then established Rukan Preschool and through Ethos International School, he continues to carry his personal vision of human development into all his projects, viewing the child as the raw material through which we can create change in our society today in order to serve our civil and humanitarian duties.</span></p>\r\n', 'Mr._Muhammad_Salah___General_Manager.JPG_1cdb1.jpg', 'muhammadsalah@ethosedu.com', '', '2015-12-01 09:06:46', '2016-10-20 10:10:02', 0, 1, 1),
(9, 'Nohha Emad', 'Head of Character Education', '<p>\r\n	<span style=\"font-size:16px;\">Ms. Nohha, our Character Education Consultant has more than 16 years work experience in character education and Counseling.Ms. Nohha has received her M.Ed from the American University in Cairo along with an MS in Applied Psycology from Middlesex University, London. She is a certified Character Education Specialist with a certification from the University of San Diego. Her functional experience is in character education, counseling and teaching</span><span style=\"font-size:16px;\"><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; font-size: 12pt; line-height: 32px; font-family: &quot;Times New Roman&quot;, serif; color: rgb(47, 47, 47); background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-origin: initial; background-clip: initial;\">.</span></span></p>\r\n', 'Ms._Nohha_Emad___Head_of_Character_Education.JPG_dd2aa.jpg', 'nohhaemad@ethosedu.com', '', '2015-12-02 14:29:45', '2020-01-09 14:52:22', 0, 1, 7),
(12, 'Dalia Elguindy', 'Head of Expressive Arts', '<p>\r\n	<span style=\"font-size:16px;\">Ms. El-Guindy graduated from AUC with a bachelor&#39;s degree in Theatre and is a member of the oldest independent theatre company in Egypt. She was theatrically trained under some of the top professionals in the industry both in Egypt and internationally. She joined Ethos International School 2016, and currently she is the Head of Expressive Arts. She was the head of Key Stage 1 for three years, with experience in marketing, events management and directing.She is a professional actress/singer with 19 years of performance experience and 15 years in the field of education<span style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">.</span>With years of experience in drama coordination, acting coaching and productions, Ms. El-Guindy highly believes that an all rounded arts education particularly one that is immersed in domestic identity, shapes the foundations of a child&#39;s personality and heightens their sense of humanity, responsibility and respect for society. She is also a professional actress/singer with 18 years of performance experience and 10 years in the field of education.</span></p>\r\n', '6B5A7004_8c5c4.jpg', 'daliaelguindy@ethosedu.com', '', '2016-08-22 09:23:46', '2020-01-09 14:39:44', 0, 1, 9),
(13, 'Youssraa Raafat', 'Co-founder', '<p>\r\n	<span style=\"font-size:16px;\">Co-Founder of Ethos International School.Graduated from the  Faculty of Law from University of Alexandria.  Co founding and managing  Rukan Preschool from  2010 till 2018. She has a vision to serve children using up-to date techniques, safe and friendly environment, and a high quality workforce. She has very high standards to education, parent-school communication and teacher performance; she always strives to offer the child a very high level of care and development.</span></p>', '', 'youssraaraafat@ethosedu.com', '', '2018-09-12 19:29:03', '2018-09-13 20:59:54', 0, 0, 2),
(14, 'Doaa Tohfa ', 'Head of Key Stage One', '<p>\r\n	<span style=\"font-size:16px;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47);\">Ms. Tohfa graduated from Commerce, English section, Ain Shams University. She spent her early years learning in an American School, and then completed her IGs in a British School. </span><span style=\"color: rgb(34, 34, 34); font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">She is a</span><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47);\">&nbsp;mother of three children who have inspired her to pursue her career in the education field. </span><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47);\">She has had 9 years of experience teaching early years and hold a Master&#39;s Degree in Special and Inclusive Education, from the University College of London.</span><span style=\"color: rgb(34, 34, 34); font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\"> Ms.Tohfa jo</span><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47);\">ined Rukan Nursery and Pre-school 2012 and then joined Ethos International School since it started.</span></span></span></p>\r\n<p>\r\n	&nbsp;</p>\r\n<p>\r\n	&nbsp;</p>\r\n', '6B5A6829_f4348.jpg', 'doaatohfa@ethosedu.com', '', '2018-09-19 09:56:42', '2020-01-12 09:07:05', 0, 1, 5),
(15, 'Christine Alphonse ', 'Head of Key Stage Three', '<p>\r\n	<span style=\"color: rgb(47, 47, 47); font-family: OpenSans-Regular; font-size: 16px;\">Ms. Alphonse holds a BA degree in English Language and Literature, a Post Graduate Degree in Languages and Translation- Cairo University and an MA degree in Teaching English as a Foreign Language from University of California &ndash; Santa Cruz. She has 22 years of experience teaching in National, British and American schools along with a wide experience as a Literacy Specialist, an IGCSE O level and AS, an English teacher, a Subject coordinator and an educational consultant. She has 10+ years&rsquo; experience as a Deputy Head teacher. She has co -founded 2 British International schools before joining Ethos, and she is passionate about education and ensuring that children reach their full potential whether academically or pastorally.</span>&nbsp;&nbsp;</p>\r\n<div>\r\n	<div dir=\"ltr\">\r\n		<div dir=\"ltr\">\r\n			<div>\r\n				<div dir=\"ltr\">\r\n					<div dir=\"ltr\">\r\n						<div dir=\"ltr\">\r\n							<div dir=\"ltr\">\r\n								<div dir=\"ltr\">\r\n									<div dir=\"ltr\">\r\n										<div dir=\"ltr\">\r\n											<br style=\"color: rgb(34, 34, 34); font-family: Arial, Helvetica, sans-serif; font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;\" />\r\n											<br />\r\n											&nbsp;</div>\r\n									</div>\r\n								</div>\r\n							</div>\r\n						</div>\r\n					</div>\r\n				</div>\r\n			</div>\r\n		</div>\r\n	</div>\r\n</div>\r\n<p>\r\n	&nbsp;</p>\r\n', '6B5A6814_f8854.jpg', 'christinealphonse@ethosedu.com', '', '2018-09-19 09:57:58', '2020-10-20 14:54:51', 0, 1, 6),
(17, 'Laila Niazy ', 'Head of Learning Support', '<p>\r\n	<span style=\"color: rgb(47, 47, 47); font-family: opensans-regular; font-size: 16px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">Ms. Niazy graduated from the Faculty of Economics &amp; Political Science, English Section from Cairo University. However, she has been working in the field of special education since 2005. Ms. Niazy started as an English &amp; Social Studies special education teacher for three years at Misr Language Schools/American Division, then was promoted to become the Special Educational Needs Coordinator (SENCO) for middle school at the same school. She has taken several certificates in the field of special education, and she was also a partner/researcher in the SPEDU Erasmus+ project. This project aimed to develop a Master&rsquo;s degree in Special Education and Inclusion. Finally, she has earned her Master&rsquo;s degree in Special and Inclusive Education from University College London. </span></p>\r\n', '6B5A6865_97a75.jpg', 'lailaniazy@ethosedu.com', '', '2018-09-19 10:01:40', '2020-01-12 09:07:57', 0, 1, 10),
(18, 'Coach Muhammad Magdy ', 'Head of Physical Education ', '<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47); font-size: 16px;\">Coach Magdy holds a B.A. &nbsp;from the Faculty of Physical Education and Sports and a High Diploma in sports injuries from the Faculty of Physical Education and Sports. He is currently the Head of Physical Education at Ethos International School. This is his 21</span><sup>ST</sup><span style=\"font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; color: rgb(47, 47, 47); font-size: 16px;\"> year of Teaching PE, He is one of the founders of ISSOC (International Schools Sports Organization of Cairo), He received the License &ldquo;C&rdquo; from the CAF in 2010, he is a certified youth fitness instructor, and he coached many school football teams, Coach at FC Barcelona Futbolnet program in Egypt.</span><span style=\"color: rgb(34, 34, 34); font-size: small; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;\">&nbsp;&nbsp; </span></span></p>\r\n', '6B5A6852_ca0e3.jpg', 'muhammadsadek@ethosedu.com', '', '2018-09-20 10:26:22', '2020-01-20 11:30:23', 0, 1, 11),
(19, 'Rasha Kayali', 'Head of Foundation Stage', '<p>\r\n	<span style=\"font-size:16px;\">Ms. Rasha Kayali graduated from Faculty of Alsun, Ain Shams University. Started working in the educational field since 2005 holding different teaching and managerial positions. She joined Ethos in 2015 as a Foundation Stage homeroom teacher, then a year group coordinator while pursuing further studies and receiving The Cambridge Diploma for&nbsp;Teaching and Learning. Ms. Kayali has always been highly committed, perseverant and has always shown passion for excellence, she believes that supporting and guiding pupils to succeed and have aspirations makes the job so exciting and gratifying, especially when those smiles of achievement are on show.</span></p>\r\n', '6B5A6798_377c5.jpg', 'rashakayali@ethosedu.com ', NULL, '2020-01-09 14:57:13', '2020-01-12 09:05:06', 0, 1, 4),
(20, 'Iman Afify', 'Head of Key Stage Two', '<p>\r\n	<span style=\"font-size:16px;\">Ms. Afifi graduated from Faculty of Al Alsun (English Department) and a CELTA certified teacher. She successfully completed a diploma in Applied Linguistics. And she has more than ten years of teaching experience. Ms.Iman Afify has joined our team with more than 6 years of experience in international education, and has been part of Ethos family for the past 3.5 years as a Key Stage 2 teacher and Deputy. Mrs. Iman is a visionary person with ethical qualities and high work standards.</span></p>\r\n<p>\r\n	<br />\r\n	&nbsp;</p>\r\n', '6B5A7022_e8572.jpg', 'imanafify@ethosedu.com ', NULL, '2020-01-12 09:25:15', '2020-02-04 10:49:58', 0, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`id`, `title`, `approved`, `weight`, `created`, `updated`) VALUES
(4, 'Term 1 2020/2021', 1, 4, '2018-12-07 20:04:34', '2018-12-07 21:52:59'),
(5, 'Term 2 2020/2021', 1, 5, '2020-10-15 14:50:39', '2020-10-15 14:50:39'),
(6, 'Term 1 2021/2022', 1, 6, '2020-11-15 11:11:23', '2020-11-15 11:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `position`, `body`, `image`, `approved`, `featured`, `created`, `updated`, `weight`) VALUES
(1, 'Mohamed Elsayed', '', '<p>\r\n	Picking the right school initially was a difficult decision, especially when moving to a foreign country which Ireland was to us when we first moved to Dublin. Even though Dublin has a vast amount of citizens from all over the world, it always feels rather lonely to uproot your family.</p>\r\n', '214650552_6106d.jpg', 1, 0, '2015-11-13 04:20:30', '2015-11-13 04:20:30', 1),
(2, 'Mohamed Elsayed2', '', '<p>\r\n	Picking the right school initially was a difficult decision, especially when moving to a foreign country which Ireland was to us when we first moved to Dublin. Even though Dublin has a vast amount of citizens from all over the world, it always feels rather lonely to uproot your family.</p>\r\n', '214650552_6106d.jpg', 1, 0, '2015-11-13 04:20:30', '2015-11-13 04:42:34', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '1',
  `email` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `group_id` int NOT NULL DEFAULT '0',
  `confirm_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `gender`, `email`, `image`, `username`, `password`, `group_id`, `confirm_code`) VALUES
(1, 'Mohamed Elsayed', 1, 'me@mohamedelsayed.net', '', 'elsayed', '63c61f7b43c855f0e736ae380004576c5c66c234', 0, NULL),
(2, 'Mohamed Elsayed', 1, 'ethos@mohamedelsayed.net', '', 'admin', '88326122b923be10c6b1dbfe118867c886b15c49', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `values`
--

CREATE TABLE `values` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text,
  `image` varchar(255) DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `weight` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `values`
--

INSERT INTO `values` (`id`, `title`, `body`, `image`, `created`, `updated`, `weight`, `approved`) VALUES
(1, 'Pursuing Excellence', '<p>\r\n	<span style=\"font-size:12px;\">We ensure that everything we do is delivered to a high standard. </span></p>\r\n', 'logo_small_213e9.jpg', '2015-11-20 03:59:02', '2020-01-27 14:13:17', 5, 1),
(2, 'Integrity', '<p>\r\n	Standing up for what we believe, being honest with ourselves and other, demonstration of fairness in our judgments and actions and fulfillment of commitments.</p>\r\n', 'logo_small_2_97373.jpg', '2015-11-20 04:40:25', '2020-01-27 14:14:03', 1, 1),
(3, 'Continuous Improvement', '<p>\r\n	Ongoing process of improvement by making small, incremental improvements.</p>\r\n', 'logo_small_3_83458.jpg', '2015-11-20 04:41:12', '2020-01-27 14:15:46', 2, 1),
(4, 'Respect', '<p>\r\n	Nurturing and modeling respect within three areas: self-respect, respect for other and respect environment. We value and appreciate diversity.</p>\r\n', 'logo_small_4_f3dbd.jpg', '2015-11-20 04:41:54', '2020-01-26 12:57:35', 3, 1),
(5, 'Caring', '<p>\r\n	Acting with insight, understanding and compassion making sure no one is left alone.</p>\r\n', 'logo_small_5_c0fd2.jpg', '2015-11-20 04:42:20', '2020-01-27 14:16:37', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hits` int NOT NULL,
  `node_id` int NOT NULL DEFAULT '0',
  `content_id` int NOT NULL DEFAULT '0',
  `event_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `title_ar` varchar(255) DEFAULT NULL,
  `body` longtext,
  `body_ar` longtext,
  `image` varchar(255) DEFAULT NULL,
  `page_id` int NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `title`, `title_ar`, `body`, `body_ar`, `image`, `page_id`, `approved`, `created`, `updated`) VALUES
(1, 'Home Image', '', '', '<p>\r\n	تست</p>\r\n', 'IMG_8734_adc74.jpg', 1, 1, '2015-11-01 21:46:44', '2020-03-02 13:24:54'),
(2, 'Empowered Minds; Ethical Characters', 'فلسفتنا', '<p>\r\n	&nbsp;</p>\r\n<p>\r\n	<strong>OUR FOCUS AREAS</strong></p>\r\n<p>\r\n	The physical, social, psychological and educational well-being of the <strong>Child. </strong></p>\r\n<p>\r\n	The sustainability and continuous improvement of the<strong> Organization.</strong></p>\r\n<p>\r\n	The development and motivation of the<strong> Staff.</strong></p>\r\n<p>\r\n	<strong>Parents&rsquo; </strong>positive involvement.</p>\r\n', '<p>\r\n	هناك حقيقة مثبتة منذ زمن طويل وهي أن المحتوى المقروء لصفحة ما سيلهي القارئ عن التركيز على الشكل الخارجي للنص أو شكل توضع الفقرات في الصفحة التي يقرأها. ولذلك يتم استخدام طريقة لوريم إيبسوم لأنها تعطي توزيعاَ طبيعياَ -إلى حد ما- للأحرف عوضاً عن استخدام &quot;هنا يوجد محتوى نصي، هنا يوجد محتوى نصي&quot; فتجعلها تبدو (أي الأحرف) وكأنها نص مقروء. العديد من برامح النشر المكتبي وبرامح تحرير صفحات الويب تستخدم لوريم إيبسوم بشكل افتراضي كنموذج عن النص، وإذا قمت بإدخال &quot;lorem ipsum&quot; في أي محرك بحث ستظهر العديد من المواقع الحديثة العهد في نتائج البحث. على مدى السنين ظهرت نسخ جديدة ومختلفة من نص لوريم إيبسوم، أحياناً عن طريق الصدفة، وأحياناً عن عمد كإدخال بعض العبارات الفكاهية إليها.</p>\r\n', '', 1, 1, '2015-11-02 00:29:19', '2020-03-02 13:41:03'),
(3, 'Slogan', NULL, '<p>\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><strong><span style=\"font-size: 48px;\">&quot;Empowered Minds;</span></strong></span></p>\r\n<p style=\"text-align: right;\">\r\n	<span style=\"font-family:arial,helvetica,sans-serif;\"><strong><span style=\"font-size: 48px;\">Ethical Characters &quot;</span></strong></span></p>\r\n', NULL, '', 1, 1, '2019-11-18 12:50:59', '2020-03-02 13:28:13');

-- --------------------------------------------------------

--
-- Table structure for table `year_groups`
--

CREATE TABLE `year_groups` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int NOT NULL DEFAULT '0',
  `applying_to` tinyint(1) NOT NULL DEFAULT '0',
  `current` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `year_groups`
--

INSERT INTO `year_groups` (`id`, `title`, `approved`, `weight`, `applying_to`, `current`, `created`, `updated`) VALUES
(1, 'Preschool', 1, 1, 1, 1, '2018-12-07 21:57:18', '2018-12-07 22:31:56'),
(2, 'Foundation Stage 1', 1, 2, 1, 1, '2018-12-07 22:00:27', '2018-12-07 22:27:46'),
(3, 'Foundation Stage 2', 1, 3, 1, 1, '2018-12-07 22:27:20', '2018-12-07 22:27:20'),
(4, 'Year 1', 1, 4, 1, 1, '2018-12-07 22:35:24', '2018-12-07 22:35:24'),
(5, 'Year 2', 1, 5, 1, 1, '2018-12-07 22:35:36', '2018-12-07 22:36:09'),
(6, 'Year 3', 1, 6, 1, 1, '2018-12-07 22:36:01', '2018-12-07 22:36:01'),
(7, 'Year 4', 1, 7, 1, 1, '2018-12-07 22:36:20', '2018-12-07 22:36:20'),
(8, 'Year 5', 1, 8, 1, 1, '2018-12-07 22:36:34', '2018-12-07 22:36:34'),
(9, 'Year 6', 1, 9, 1, 1, '2018-12-07 22:36:46', '2018-12-07 22:36:46'),
(10, 'Year 7', 1, 10, 1, 1, '2018-12-07 22:37:04', '2018-12-07 22:37:04'),
(11, 'Year 8', 1, 11, 1, 1, '2018-12-07 22:37:18', '2018-12-07 22:37:18'),
(12, 'Year 9', 1, 12, 1, 1, '2018-12-07 22:37:33', '2020-01-08 23:17:25'),
(13, 'Year 10', 1, 13, 1, 1, '2018-12-15 22:52:47', '2018-12-15 22:52:47'),
(14, 'Year 11', 1, 14, 1, 1, '2018-12-15 22:53:12', '2018-12-15 22:53:12'),
(15, 'Year 12', 1, 15, 1, 1, '2018-12-15 22:53:30', '2018-12-15 22:53:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academics`
--
ALTER TABLE `academics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `agreements`
--
ALTER TABLE `agreements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attend_events`
--
ALTER TABLE `attend_events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audios`
--
ALTER TABLE `audios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blocked_members`
--
ALTER TABLE `blocked_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cats`
--
ALTER TABLE `cats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `developments`
--
ALTER TABLE `developments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `disclaimers`
--
ALTER TABLE `disclaimers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forum_comments`
--
ALTER TABLE `forum_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gals`
--
ALTER TABLE `gals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logos`
--
ALTER TABLE `logos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletters`
--
ALTER TABLE `newsletters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nodes`
--
ALTER TABLE `nodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orientations`
--
ALTER TABLE `orientations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queues`
--
ALTER TABLE `queues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `application_number` (`application_number`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshows`
--
ALTER TABLE `slideshows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- Indexes for table `values`
--
ALTER TABLE `values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `year_groups`
--
ALTER TABLE `year_groups`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academics`
--
ALTER TABLE `academics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `agreements`
--
ALTER TABLE `agreements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `albums`
--
ALTER TABLE `albums`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attend_events`
--
ALTER TABLE `attend_events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audios`
--
ALTER TABLE `audios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blocked_members`
--
ALTER TABLE `blocked_members`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `careers`
--
ALTER TABLE `careers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cats`
--
ALTER TABLE `cats`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `developments`
--
ALTER TABLE `developments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `disclaimers`
--
ALTER TABLE `disclaimers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forum_comments`
--
ALTER TABLE `forum_comments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gals`
--
ALTER TABLE `gals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=518;

--
-- AUTO_INCREMENT for table `logos`
--
ALTER TABLE `logos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsletters`
--
ALTER TABLE `newsletters`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nodes`
--
ALTER TABLE `nodes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orientations`
--
ALTER TABLE `orientations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `queues`
--
ALTER TABLE `queues`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slideshows`
--
ALTER TABLE `slideshows`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `values`
--
ALTER TABLE `values`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `year_groups`
--
ALTER TABLE `year_groups`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
